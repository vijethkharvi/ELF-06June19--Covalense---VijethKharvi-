package com.covalense.springboot.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@SuppressWarnings("serial")
//@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name="employee_otherinfo")
public class EmployeeOtherInfoBean implements Serializable{
	
	//@JsonIgnore
	@Id
	@Column(name="other_info_id")
	@GeneratedValue
	private Integer otherinfoid;
	
	//@JsonIgnore
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="id",referencedColumnName="id",unique = true,nullable = false)
	private EmployeeInfoBean empInfo;

	
	
	
	
	//@JsonBackReference
	//@XmlTransient  //<===@JsonIgnore (similar)
	//@JsonIgnore
	//@OneToOne
	//@Id
	//@JoinColumn(name="id")
	//@PrimaryKeyJoinColumn(name="ID")
	
	
	
	public Integer getOtherinfoid() {
		return otherinfoid;
	}

	public void setOtherinfoid(int otherinfoid) {
		this.otherinfoid = otherinfoid;
	}

	@Column(name="pan")
	private String pan;
	
	@Column(name="ismarried")
	private Boolean ismarried;
	
	@Column(name="blood_group")
	private String bloodGroup;
	
	@Column(name="ischallenged")
	private Boolean ischallenged;
	
	@Column(name="emergency_contact_number")
	private Long emergencyContactNum;
	
	@Column(name="emergency_contact_name")
	private String emergencyContactName;
	
	@Column(name="nationality")
	private String nationality;
	
	@Column(name="religion")
	private String religion;
	
	@Column(name="father_nm")
	private String fatherName;
	
	@Column(name="mother_nm")
	private String motherName;
	
	@Column(name="spouse_nm")
	private String spouseName;
	
	@Column(name="passport")
	private String passport;
	
	@Column(name="adhar")
	private Long adhar;

	public EmployeeInfoBean getEmpInfo() {
		return empInfo;
	}

	public void setEmpInfo(EmployeeInfoBean empInfo) {
		this.empInfo = empInfo;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public Boolean isIsmarried() {
		return ismarried;
	}

	public void setIsmarried(boolean ismarried) {
		this.ismarried = ismarried;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public Boolean isIschallenged() {
		return ischallenged;
	}

	public void setIschallenged(boolean ischallenged) {
		this.ischallenged = ischallenged;
	}

	public Long getEmergencyContactNum() {
		return emergencyContactNum;
	}

	public void setEmergencyContactNum(long emergencyContactNum) {
		this.emergencyContactNum = emergencyContactNum;
	}

	public String getEmergencyContactName() {
		return emergencyContactName;
	}

	public void setEmergencyContactName(String emergencyContactName) {
		this.emergencyContactName = emergencyContactName;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getSpouseName() {
		return spouseName;
	}

	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}

	public String getPassport() {
		return passport;
	}

	public void setPassport(String passport) {
		this.passport = passport;
	}

	public Long getAdhar() {
		return adhar;
	}

	public Boolean getIsmarried() {
		return ismarried;
	}

	public void setIsmarried(Boolean ismarried) {
		this.ismarried = ismarried;
	}

	public Boolean getIschallenged() {
		return ischallenged;
	}

	public void setIschallenged(Boolean ischallenged) {
		this.ischallenged = ischallenged;
	}

	public void setOtherinfoid(Integer otherinfoid) {
		this.otherinfoid = otherinfoid;
	}

	public void setEmergencyContactNum(Long emergencyContactNum) {
		this.emergencyContactNum = emergencyContactNum;
	}

	public void setAdhar(Long adhar) {
		this.adhar = adhar;
	}

	public void setAdhar(long adhar) {
		this.adhar = adhar;
	}

}
